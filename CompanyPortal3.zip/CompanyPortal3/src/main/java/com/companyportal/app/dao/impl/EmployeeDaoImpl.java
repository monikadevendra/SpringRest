package com.companyportal.app.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.companyportal.app.dao.EmployeeDao;
import com.companyportal.app.entity.Employee;


@Repository
public class EmployeeDaoImpl implements EmployeeDao{
	
	@Autowired
	SessionFactory sessionFactory;
	private ArrayList<Employee> employeeList = new ArrayList<Employee>();

	@Override
	public void saveEmployeeData(Employee employee) {
		Session session=sessionFactory.openSession();
        session.beginTransaction();
        session.persist(employee);
        session.getTransaction().commit();
        System.out.println("Employee Record added.");
        session.close();
	}

	@Override
	public List<Employee> getEmployeesData() {
		List<Employee> list=new ArrayList<Employee>();
		Session session=sessionFactory.openSession();
        session.beginTransaction();
		String hql="from Employee";
        Query query=session.createQuery(hql);
        list=query.list();
        session.getTransaction().commit();
        session.close();
		return list;

	}
	
		@Override
	    public void updateEmployee(Employee employee,Integer empNo) {
	        Session session=sessionFactory.openSession();
	        session.beginTransaction();
	        String queryString = "UPDATE Employee SET name = :name, project= :project,"
	                + " mailId= :mailId, phoneNo= :phoneNo  WHERE employeeId= :employeeId ";
	        Query query = session.createQuery(queryString);
	        query.setParameter("name", employee.getName());
	        query.setParameter("project", employee.getProject());
	        query.setParameter("mailId", employee.getMailId());
	        query.setParameter("phoneNo", employee.getPhoneNo());
	        query.setParameter("employeeId", empNo);
	        query.executeUpdate();
	        session.getTransaction().commit();
	        System.out.println("Employee Updated");
	        session.close();
	    }

	 
		@Override
	    public void deleteEmployee(Integer empNo) {
	        Session session=sessionFactory.openSession();
	        session.beginTransaction();
	        String queryString = "delete from Employee  where employeeId= :employeeId ";
	        Query query = session.createQuery(queryString);
	        query.setParameter("employeeId", empNo);
	        query.executeUpdate();
	        session.getTransaction().commit();
	        System.out.println("Employee Deleted");
	        session.close();
	        
	    }

		@Override
		public List<Employee> searchEmployeeByName(String employeeName) {
			// TODO Auto-generated method stub
			List<Employee> list=new ArrayList<Employee>();
			Session session=sessionFactory.openSession();
	        session.beginTransaction();
	        String queryString= "from Employee where name like:employeeName";
	        Query query = session.createQuery(queryString);
	        query.setParameter("employeeName","%"+employeeName + "%");
	        list=query.list();
	        session.getTransaction().commit();
	        System.out.println("Employee Deleted");
	        session.close();
			return list;
		}

		

}
