package com.companyportal.app.service;

import java.util.List;

import com.companyportal.app.entity.Employee;

public interface EmployeeService {

	public void saveEmployeeData(Employee employee);

	public List<Employee> getEmployeesData();
	
	public Employee searchEmployeeByEno(int empNo);
	
	public void updateEmployee(Employee e, Integer empId);
	
	public void deleteEmployee(Integer empNo);

	public List<Employee> searchEmployeeByName(String employeeName);
}
